
public class State_Start extends State_Base
{
	private Game myGame;
	private Key_Listener myListener;
	
	public State_Start(Game aGame,Key_Listener someListener)
	{
		myGame = aGame;
		myListener = someListener;
	}
	
	public void run(long startTime)
	{
		draw();
		if (StdDraw.mousePressed())
		{
			myGame.setState("Instruction");
			StdDraw.setMousePressed(false);
		}
	}
	
	public void draw()
	{
		StdDraw.picture(Game.WINDOW_WIDTH/2,Game.WINDOW_HEIGHT/2,"Images/Title_Screen.png");
	}
}
