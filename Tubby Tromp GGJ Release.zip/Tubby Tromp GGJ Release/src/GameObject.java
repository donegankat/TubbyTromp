import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;


/**Highest level class for objects in the game.
 * All other object entities extend GameObject
 * 
 * @author Mitch
 *
 */

public class GameObject 
{
	protected double myX, myY;
	protected double myXVelocity,myYVelocity,myYAcceleration;
	protected int myWidth, myHeight;
	protected String myImage;
	public boolean isAlive, isJumping, isOnGround;
	public int state; //0 = running, 1 = eating, 2 = jumping
	public int objType; //0 = player, 1 = food, 2 = platform
	protected Animation run;
	protected Animation eat;
	protected Animation jump;
	protected Animation foodLeft;
	protected Animation foodRight;
	long foodTime;
	protected Image currentImage;
	boolean isEating;
	Image objectImage;	
	public int direction = 0;
	public int foodType;

	public GameObject()
	{
		myX = myY = 0;
		myXVelocity = myYVelocity = 0;
		myYAcceleration = 0;
		myWidth = myHeight = 0;
		isAlive = isOnGround = true;
		isJumping = isEating =  false;
		state = 0;
		objType = 0;
	}

	public GameObject(double someX,double someY,int someWidth,int someHeight,String someImage)
	{
		myX = someX;
		myY = someY;
		myWidth = someWidth;
		myHeight = someHeight;
		myXVelocity = 6;
		myYVelocity = 0;
		myYAcceleration = 0;
		isAlive = isOnGround = true;
		isJumping = isEating =false;
		state = 3;
		myImage = someImage;//getImage("Images/" + someImage);
		objType = 2;
	}

	public GameObject(double someX,double someY,int someWidth,int someHeight,Image img)
	{
		myX = someX;
		myY = someY;
		myWidth = someWidth;
		myHeight = someHeight;
		myXVelocity = 6;
		myYVelocity = 0;
		myYAcceleration = 0;
		isAlive = isOnGround = true;
		isJumping = isEating =false;
		state = 3;
		currentImage = img;
		objType = 2;
	}

	public GameObject(double someX,double someY,int someWidth,int someHeight, Animation r, Animation e,Animation j)
	{
		myX = someX;
		myY = someY;
		myWidth = someWidth;
		myHeight = someHeight;
		myXVelocity = 6;
		myYVelocity = 0;
		myYAcceleration = 0;
		isAlive = isOnGround = true;
		isJumping = isEating =false;
		state = 0;
		run = r;
		eat = e;
		jump = j;
		objType = 0;
	}

	public GameObject(double someX,double someY,int someWidth,int someHeight, Animation fl, Animation fr)
	{
		myX = someX;
		myY = someY;
		myWidth = someWidth;
		myHeight = someHeight;
		myXVelocity = 3;
		myYVelocity = 0;
		myYAcceleration = 0;
		isAlive = isOnGround = true;
		isJumping = isEating =false;
		state = 0;
		foodLeft = fl;
		foodRight = fr;
		objType = 1;
	}

	public Image getImage(String imageName)
	{
		return new ImageIcon(imageName).getImage();
	}

	public void draw()
	{
		//StdDraw.picture(myX, myY, myImage);
		//StdDraw.setPenColor(StdDraw.BLACK);
		//StdDraw.filledSquare(myX, myY,myWidth);
		
		if(objType == 0)
		{
			if(state == 0) //running
			{
				StdDraw.picture(myX, myY, run.getImage());
			}
			else if(state == 1) //eating
			{
				StdDraw.picture(myX, myY, eat.getImage());
			}
			else if(state == 2) //jumping
			{
				if(myYVelocity > 0)
				{
					StdDraw.picture(myX, myY, jump.getFrameImage(0));
				}
				else
				{
					if(myY > 150)
					{
						StdDraw.picture(myX, myY, jump.getFrameImage(1));
					}
					else
					{
						StdDraw.picture(myX, myY, jump.getFrameImage(2));
					}
				}

			}
			else
			{
				//StdDraw.picture(myX, myY, objectImage);
				//this is probably when we would be on a title screen
			}
		}
		else if(objType == 1)
		{
			//if(direction == 0)
			//{
				//StdDraw.picture(myX, myY, foodRight.getImage());
				StdDraw.picture(myX, myY, "Images/cookieWalkR1.png");
			//}
			//else
			//{
			//	StdDraw.picture(myX, myY, foodLeft.getImage());
			//}

		}

	}

	public void update(long elapsedTime)
	{

		if(isEating)
		{
			state = 1;

			if(elapsedTime % 20 == 0)
			{
				SoundEffect.TEETH.play();
			}

			//SoundEffect.WALKING.stop();
		}
		else if(!isOnGround)
		{
			state = 2;

			//SoundEffect.WALKING.stop();
		}
		else
		{
			state = 0;
		}

		//Movement update
		Physics_Engine.applyGravity(this);
		myY = myY + myYVelocity;
		myYVelocity = myYVelocity + myYAcceleration;
		if (Physics_Engine.isOnGround(this))
		{
			myYVelocity = 0;
			isOnGround = true;
			isJumping = false;
		}
		else
		{
			if ((Physics_Engine.isOnPlatform(this,Game.thePlatformObjects))||(Physics_Engine.isOnPlatform(this,Game.theBlockObjects)))
			{
				myYVelocity = 0;
				isOnGround = true;
				isJumping = false;
			}
			else
			{
				isOnGround = false;
				isJumping = true;
			}
		}
	}

	public void jump()
	{
		if (isOnGround == true)
		{
			myYVelocity = 10.0;

			if(objType == 0)
			{
				Random r = new Random();
				int n = r.nextInt(20);
				if(n <= 5)
				{
					SoundEffect.JUMP1.play();
				}
				else
				{
					SoundEffect.JUMP2.play();
				}
			}
		}
	}

	public boolean doesCollide(GameObject anotherObject)
	{
		double offsetTemp = 0.0;
		if((this.getX() + this.getWidth() >= anotherObject.getX() - anotherObject.getWidth()+offsetTemp) && (this.getX()-this.getWidth() + offsetTemp <= anotherObject.getX() + anotherObject.getWidth()))
		{
			if((this.getY() + this.getHeight() >= anotherObject.getY()-anotherObject.getHeight()) && (this.getY()-this.getHeight() <= anotherObject.getY() + anotherObject.getHeight()))
			{
				//collision
				return true;
			}
		}
		return false;
	}

	/***************Getters and Setters for GameObjects**************/
	public void setX(double someX)
	{
		myX = someX;
	}
	public double getX()
	{
		return myX;
	}
	public int getWidth()
	{
		return myWidth;
	}
	public int getHeight()
	{
		return myHeight;
	}
	public void setY(double someY)
	{
		myY = someY;
	}
	public double getY()
	{
		return myY;
	}
	public void setXVelocity(double someVelocity)
	{
		myXVelocity = someVelocity;
	}
	public double getXVelocity()
	{
		return myXVelocity;
	}
	public void setYVelocity(double someYVelocity)
	{
		myYVelocity = someYVelocity;
	}
	public double getYVelocity()
	{
		return myYVelocity;
	}
	public void setYAcceleration(double someAcceleration)
	{
		myYAcceleration = someAcceleration;
	}
	public double getYAcceleration()
	{
		return myYAcceleration;
	}


}
