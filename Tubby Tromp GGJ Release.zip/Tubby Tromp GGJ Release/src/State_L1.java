import java.util.ArrayList;


public class State_L1 extends State_Base
{
	private Game myGame;
	private Player myPlayer;
	private Key_Listener myKeyListener;
	public AssetManager assetManager;
	private GameRules gameRules;
	public static int backgroundX;
	public static int backgroundX2;
	public static int floorX;
	public static int floorX2;
	// private LevelObject lo;
	
	public State_L1(Game aGame, Key_Listener keyListener)
	{
		myGame = aGame;
		assetManager = new AssetManager();
		gameRules = new GameRules();
		myPlayer = new Player(70.0,300.0,70,100,assetManager.playerAnim[0], assetManager.playerAnim[1], assetManager.playerAnim[2]);
		myPlayer.state = 0;
		myKeyListener = keyListener;
		Game.thePlatformObjects = new ArrayList<LevelObject>();
		Game.theBlockObjects = new ArrayList<LevelObject>();
		Game.theFoodObjects = new ArrayList<Food>();
		backgroundX = 1985/2;
		backgroundX2 = 1985/2 + 1985;
		floorX = 1985/2;
		floorX2 = 1985/2 + 1985;
		init();
	}
	
	public void init()
	{
		//lo = new LevelObject(50.0,50.0,100,100,assetManager.objectImages.get(0));
		ObjectFactory.createObject(assetManager, "Platform","1",myPlayer.getX()-Game.WINDOW_WIDTH+800);
		ObjectFactory.createObject(assetManager, "Platform","1",myPlayer.getX()-Game.WINDOW_WIDTH+300);
		ObjectFactory.createObject(assetManager, "Food","1",myPlayer.getX()-Game.WINDOW_WIDTH);
	}
	
	
	public void run(long start)
	{
		long elapsedTime = System.currentTimeMillis() - start;
		StdDraw.clear();
		drawBackground();
		drawObjects();
		updateObjects(elapsedTime);
		ObjectFactory.generateObjects(assetManager, (int)myPlayer.getX());
		checkKeyPressed();
		StdDraw.show(5);
		ObjectFactory.removeOldObjects((int)myPlayer.getX());
		
		if (gameRules.playerIntersectsFood(myPlayer))
		{
			//We have eaten a piece of food
			//myPlayer.state = 1;
			gameRules.setScore(gameRules.getScore() + 10);
			gameRules.setCalories(gameRules.getCalories()+200);
			
			
			//Game.getMusic().mute();
			//Game.getScaryMusic().unMute();
		}
		
		if (gameRules.playerStarved())
		{
			myGame.setState("GameOver");
		}
	}
	
	public void drawObjects()
	{
		
		for (int i =0;i<Game.thePlatformObjects.size();i++)
		{
			Game.thePlatformObjects.get(i).draw();
		}
		for (int i =0;i<Game.theFoodObjects.size();i++)
		{
			Game.theFoodObjects.get(i).draw();
		}
		for (int i =0;i<Game.theBlockObjects.size();i++)
		{
			Game.theBlockObjects.get(i).draw();
		}
		myPlayer.draw();
		
		
		StdDraw.setPenColor(StdDraw.BLACK);
		double[] calBoxX = new double[] {0,250,250,0};
		double[] calBoxY = new double[] {595,595,550,550};
		StdDraw.polygon(calBoxX,calBoxY);
		
		StdDraw.setPenColor(StdDraw.GREEN);
		double[] calX = new double[] {0,gameRules.calories/(550/250),gameRules.calories/(550/250),0};
		double[] calY = new double[] {595,595,550,550};
		StdDraw.filledPolygon(calX,calY);
	}
	

	public void drawBackground()
	{
		StdDraw.picture(backgroundX, Game.WINDOW_HEIGHT/2, "Images/Background_1.png");
			if (backgroundX<=-2000)
			{
				backgroundX = 1980/2 + 1980;
			}
			if (backgroundX2<=-2000)
			{
				backgroundX2 = 1980/2 + 1980;
			}
		StdDraw.picture(backgroundX2, Game.WINDOW_HEIGHT/2, "Images/Background_1.png");
		StdDraw.picture(floorX,-100,"Images/MainGround.png");
		StdDraw.picture(floorX2,-100,"Images/MainGround.png");
		if (floorX < -2000)
		{
			floorX = 1980/2 + 1980;
		}
		if (floorX2 < -2000)
		{
			floorX2 = 1980/2 + 1980;
		}
	}


	
	public void updateObjects(long someTime)
	{		
		myPlayer.update(someTime);
		assetManager.update(someTime);
		gameRules.update(someTime);
		
		if(myPlayer.isOnGround && !myPlayer.isEating)
		{
			SoundEffect.WALKING.playOnce();
		}
		else
		{
			SoundEffect.WALKING.stop();
		}
		
		for (int i =0;i<Game.theFoodObjects.size();i++)
		{
			Game.theFoodObjects.get(i).update(someTime,myPlayer);
			
			double xDist = Math.abs(myPlayer.getX() - Game.theFoodObjects.get(i).getX());
			
			if(xDist <= 100)
			{
				myPlayer.isEating = true;
				myPlayer.state = 1;
				break;
			}
			else
			{
				myPlayer.isEating = false;
				myPlayer.state = 0;
			}
		}
	}
	
	public void checkKeyPressed()
	{
		myPlayer.moveRight();
		/*
		if(myKeyListener.isLeftPressed())
		{
			myPlayer.moveLeft();
	
		}
		if (myKeyListener.isRightPressed())
		{
			myPlayer.moveRight();
		}
		*/
		if (myKeyListener.isSpacePressed())
		{
			myPlayer.jump();
			myPlayer.state = 2;
		}
	}
}