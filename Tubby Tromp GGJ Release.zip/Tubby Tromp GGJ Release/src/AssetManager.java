import java.awt.Image;
import java.util.ArrayList;
import javax.swing.ImageIcon;
public class AssetManager
{
	public Animation[] playerAnim;
	public Animation[] foodAnim;
	public ArrayList<Image> objectImages;
	
	public AssetManager()
	{
		loadPlayerSprites();
		loadFoodSprites();
		objectImages = new ArrayList<Image>();
	}
	
	public Image loadImage(String name)
	{
		String filename = "Images/" + name;
		return new ImageIcon(filename).getImage();
	}
	   
	public void loadPlayerSprites()
	{
		Image[][] playerImages = new Image[3][];
		
		//Run
		playerImages[0] = new Image[]
		{
			loadImage("FatKid_Run_1.png"),
			loadImage("FatKid_Run_2.png"),
			loadImage("FatKid_Run_3.png"),
			loadImage("FatKid_Run_4.png"),
			loadImage("FatKid_Run_5.png"),
			loadImage("FatKid_Run_6.png")
		};
		
		//Eat
		playerImages[1] = new Image[]
		{
			loadImage("FatKid_Chomp_1.png"),
			loadImage("FatKid_Chomp_2.png"),
		};
		
		//Jump
		playerImages[2] = new Image[]
		{
			loadImage("FatKid_Jump_1.png"),
			loadImage("FatKid_Jump_2.png"),
			loadImage("FatKid_Jump_3.png")
		};
		
		playerAnim = new Animation[3]; //0 = run, 1 = eat, 2 = jump
				
		playerAnim[0] = createPlayerRunAnim(playerImages[0][0], playerImages[0][1], playerImages[0][2], playerImages[0][3], playerImages[0][4], playerImages[0][5]);
		playerAnim[1] = createPlayerChompAnim(playerImages[1][0], playerImages[1][1]);
		playerAnim[2] = createPlayerJumpAnim(playerImages[2][0], playerImages[2][1], playerImages[2][2]);
	}
	
	public void loadFoodSprites()
	{
		Image[][] foodImages = new Image[4][];
		
		//0 = Cookie, 1 = Donut, 2 = Twinkie
		foodImages[0] = new Image[]
		{
			loadImage("cookieWalkR1.png"),
			loadImage("cookieWalkR2.png"),
			loadImage("cookieWalkR3.png"),
		};
		
		foodImages[1] = new Image[]
		{
			loadImage("cookieWalkR1.png"),
			loadImage("cookieWalkR1.png"),
			loadImage("cookieWalkR1.png"),
		};
		
		foodImages[2] = new Image[]
		{
			loadImage("Cherry_Enemy.png"),
			loadImage("Cherry_Enemy_2.png"),
		};
		
		foodImages[3] = new Image[]
		{
			loadImage("Cherry_EnemyR.png"),
			loadImage("Cherry_EnemyR_2.png"),
		};

		
		
		foodAnim = new Animation[4];
		
		for(int i = 0; i < 2; i++)
		{
			foodAnim[i] = createFoodAnim(foodImages[i][0], foodImages[i][1], foodImages[i][2]);
		}
		for(int i = 2; i < 4; i++)
		{
			foodAnim[i] = createCherryAnim(foodImages[i][0], foodImages[i][1]);
		}
	}
	
    private Animation createPlayerRunAnim(Image player1, Image player2, Image player3, Image player4, Image player5, Image player6)
    {
            Animation anim = new Animation();
            anim.addFrame(player1, 4);
            anim.addFrame(player2, 6);
            anim.addFrame(player3, 8);
            anim.addFrame(player4, 10);
            anim.addFrame(player5, 12);
            anim.addFrame(player6, 14);

            return anim;
     }
    
    private Animation createPlayerChompAnim(Image player1, Image player2)
    {
            Animation anim = new Animation();
            anim.addFrame(player1, 4);
            anim.addFrame(player2, 6);

            return anim;
     }
    
    private Animation createPlayerJumpAnim(Image player1, Image player2, Image player3)
    {
            Animation anim = new Animation();
            anim.addFrame(player1, 10);
            anim.addFrame(player2, 15);
            anim.addFrame(player3, 15);

            return anim;
     }
    
    private Animation createFoodAnim(Image img1, Image img2, Image img3)
    {
    	Animation anim = new Animation();
    	anim.addFrame(img1, 0);
    	anim.addFrame(img2, 2);
    	anim.addFrame(img1, 4);
    	anim.addFrame(img2, 6);
    	anim.addFrame(img3, 8);
    	anim.addFrame(img2, 10);
    	return anim;
    }
    
    private Animation createCherryAnim(Image img1, Image img2)
    {
    	Animation anim = new Animation();
    	anim.addFrame(img1, 4);
    	anim.addFrame(img2, 8);

    	return anim;
    }
      
    public void update(long elapsedTime)
    {
    	for(int i = 0; i < 3; i++)
    	{
    		playerAnim[i].update(elapsedTime);
    	}
    	
    	for(int i = 0; i < 4; i++)
    	{
    		foodAnim[i].update(elapsedTime);
    	}
    	
    }
}