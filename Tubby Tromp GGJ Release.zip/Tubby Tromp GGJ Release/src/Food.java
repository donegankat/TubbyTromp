
public class Food extends GameObject
{
	private int patrolDistance;
	private enum foodState {PATROL_STATE,RUN_STATE};
	private foodState myState;
	private int patrolCounter = 0;
	
	public Food()
	{
		super();

		patrolDistance = 500;
		myXVelocity = 2.5; //generates a speed that will be between 15 and 50 (inclusive)
		myState = foodState.PATROL_STATE;
		objType = 1;
		direction = 0;
	}
	
	public Food(double someX,double someY,int someWidth,int someHeight,String someImage)
	{
		super(someX,someY,someWidth,someHeight,someImage);

		myXVelocity = 2.5;
		patrolDistance = 500;
		myState = foodState.PATROL_STATE;
		objType = 1;
		direction = 0;
	}
	
	public Food(double someX,double someY,int someWidth,int someHeight,Animation fl, Animation fr)
	{
		super(someX,someY,someWidth,someHeight,fl,fr);

		myXVelocity = 2.5;
		patrolDistance = 500;
		myState = foodState.PATROL_STATE;
		objType = 1;
		direction = 0;
	}
	
	public Food(double someX,double someY,int someWidth,int someHeight,String someImage,int somepatrolDistance)
	{
		super(someX,someY,someWidth,someHeight,someImage);

		myXVelocity = 2.5;
		myState = foodState.PATROL_STATE;
		patrolDistance = somepatrolDistance;
		objType = 1;
		direction = 0;
	}
	
	public void update(long elapsedTime,Player somePlayer)
	{
		super.update(elapsedTime);
		move(somePlayer);
		//this.myX = this.myX + myXVelocity;
	}
	
	public void move(Player somePlayer)
	{
		if (myState == foodState.PATROL_STATE)
		{
				this.myX = this.myX + myXVelocity;
				patrolCounter++;
				if (Math.abs(myX-somePlayer.getX())<300)
				{
					myState = foodState.RUN_STATE;
				}
			if (Math.abs(patrolCounter*myXVelocity) > patrolDistance)
			{
				patrolCounter = 0;
				myXVelocity = myXVelocity*-1;
			}
		}
		else 
		{
			myXVelocity = Math.abs(myXVelocity);
			if (somePlayer.getX()<myX)
			{
				moveRight();
				direction = 0;
			}
			else
			{
				moveLeft();
				direction = 1;
			}
		}
	}
	
	public void moveRight()
	{
		direction = 0;
		myX = myX + myXVelocity;
		if (Physics_Engine.isRightCollision(this,Game.thePlatformObjects))
		{
		super.jump();
		}
	}
	
	public void moveLeft()
	{
		direction = 1;
		myX = myX - myXVelocity;
		if (Physics_Engine.isRightCollision(this,Game.thePlatformObjects))
		{
		super.jump();
		}
	}
	
	
	
	public void draw()
	{
		super.draw();
		//StdDraw.setPenColor(StdDraw.RED);
		//StdDraw.filledSquare(myX,myY,myWidth);
	}
}
