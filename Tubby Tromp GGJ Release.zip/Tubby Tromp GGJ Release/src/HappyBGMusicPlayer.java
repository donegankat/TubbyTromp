import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * This is an example program that demonstrates how to play back an audio file
 * using the SourceDataLine in Java Sound API.
 * @author www.codejava.net
 *
 */
public class HappyBGMusicPlayer implements Runnable {

	FloatControl happyVol;
	
	public void run()
	{
		try {
			play("Sounds/happy_music.wav");
			happyVol.equals(0);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	// size of the byte buffer used to read/write the audio stream
	private static final int BUFFER_SIZE = 4096;

	/**
	 * Play a given audio file.
	 * @param audioFilePath Path of the audio file.
	 */
	void play(String audioFilePath) {
		File audioFile = new File(audioFilePath);
		try {
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(audioFile);

			AudioFormat format = audioStream.getFormat();

			DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);

			SourceDataLine audioLine = (SourceDataLine) AudioSystem.getLine(info);

			audioLine.open(format);

			audioLine.start();

			System.out.println("Playback started.");

			byte[] bytesBuffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			happyVol = (FloatControl)audioLine.getControl(FloatControl.Type.MASTER_GAIN);
			
			while ((bytesRead = audioStream.read(bytesBuffer)) != -1) {
				audioLine.write(bytesBuffer, 0, bytesRead);
			}

			audioLine.drain();
			audioLine.close();
			audioStream.close();

			System.out.println("Playback completed.");

		} catch (UnsupportedAudioFileException ex) {
			System.out.println("The specified audio file is not supported.");
			ex.printStackTrace();
		} catch (LineUnavailableException ex) {
			System.out.println("Audio line for playing back is unavailable.");
			ex.printStackTrace();
		} catch (IOException ex) {
			System.out.println("Error playing the audio file.");
			ex.printStackTrace();
		}      
	}
	
	public void unMute()
	{
		happyVol.equals(0);
	}
	
	public void mute()
	{
		happyVol.equals(-100);
	}

}





/*
import javax.sound.sampled.*;
   import javax.sound.*;
   import java.io.*;


   public class BGMusicPlayer {

	  public BGMusicPlayer(String filenameHappy, String filenameScary){

           int total, totalToRead, numBytesToReadHappy, numBytesToReadScary, numBytesRead;
           byte[] bufferHappy, bufferScary;
           boolean         stopped;
           AudioFormat     wav;
           TargetDataLine  lineHappy;
           SourceDataLine  lineInHappy;
           DataLine.Info   infoHappy;
           File            fileHappy;
           FileInputStream fisHappy;

           TargetDataLine  lineScary;
           SourceDataLine  lineInScary;
           DataLine.Info   infoScary;
           File            fileScary;
           FileInputStream fisScary;

           //AudioFormat(float sampleRate, int sampleSizeInBits, 
           //int channels, boolean signed, boolean bigEndian) 
           wav = new AudioFormat(44100, 16, 2, true, false);
           infoHappy = new DataLine.Info(SourceDataLine.class, wav);
           infoScary = new DataLine.Info(SourceDataLine.class, wav);


           bufferHappy = new byte[1024*333];
           bufferScary = new byte[1024*333];
           numBytesToReadHappy = 1024*333;
           numBytesToReadScary = 1024*333;
           total=0;
           stopped = false;

           if (!AudioSystem.isLineSupported(infoHappy)) {
               System.out.print("no support for " + wav.toString() );
           }
           if (!AudioSystem.isLineSupported(infoScary)) {
               System.out.print("no support for " + wav.toString() );
           }
           try {
               // Obtain and open the line.
               lineInHappy = (SourceDataLine) AudioSystem.getLine(infoHappy);
               lineInHappy.open(wav);
               lineInHappy.start();
               fisHappy = new FileInputStream(fileHappy = new File(filenameHappy));

               lineInScary = (SourceDataLine) AudioSystem.getLine(infoScary);
               lineInScary.open(wav);
               lineInScary.start();
               fisScary = new FileInputStream(fileScary = new File(filenameScary));


               totalToRead = fisHappy.available();


               FloatControl happyVol = (FloatControl)lineInHappy.getControl(FloatControl.Type.MASTER_GAIN);
               FloatControl scaryVol = (FloatControl)lineInScary.getControl(FloatControl.Type.MASTER_GAIN);

               happyVol.setValue(0);
               scaryVol.setValue(-100);
               //lineIn.getControl(FloatControl.Type.MASTER_GAIN).equals(-100);

               while (total < totalToRead && !stopped){
                   numBytesRead = fisHappy.read(bufferHappy, 0, numBytesToReadHappy);
                   numBytesRead = fisScary.read(bufferScary, 0, numBytesToReadScary);
                   if (numBytesRead == -1) break;

                   total += numBytesRead;
                   lineInHappy.write(bufferHappy, 0, numBytesRead);
                   lineInScary.write(bufferScary, 0, numBytesRead);
               }

           } catch (LineUnavailableException ex) {
               ex.printStackTrace();
           } catch (FileNotFoundException nofile) {
               nofile.printStackTrace();
           } catch (IOException io) {
               io.printStackTrace();
           }
   }
/*
           public static void main(String[] argv) {
        	   //BGMusicPlayer mb_745 = new BGMusicPlayer(argv[0]);
        	   BGMusicPlayer music = new BGMusicPlayer("Sounds/happy_music.wav", "Sounds/scary_music.wav");

           }
 */
//   }












/*
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

public class BGMusicPlayer {

JFrame j;

public BGMusicPlayer() {
   // j = new JFrame("SoundMeter");
   // j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   // j.setLayout(new BoxLayout(j.getContentPane(), BoxLayout.Y_AXIS));
    printMixersDetails();
   // j.setVisible(true);
}
public void printMixersDetails(){
    javax.sound.sampled.Mixer.Info[] mixers = AudioSystem.getMixerInfo();
    System.out.println("There are " + mixers.length + " mixer info objects");  
    for(int i=0;i<mixers.length;i++){
        Mixer.Info mixerInfo = mixers[i];
        System.out.println("Mixer Name:"+mixerInfo.getName());
        Mixer mixer = AudioSystem.getMixer(mixerInfo);
        Line.Info[] lineinfos = mixer.getTargetLineInfo();
        for(Line.Info lineinfo : lineinfos){
            System.out.println("line:" + lineinfo);
            try {
                Line line = mixer.getLine(lineinfo);
                line.open();
                if(line.isControlSupported(FloatControl.Type.VOLUME)){
                    FloatControl control = (FloatControl) line.getControl(FloatControl.Type.VOLUME);
                    System.out.println("Volume:"+control.getValue());   
                    JProgressBar pb = new JProgressBar();
                    // if you want to set the value for the volume 0.5 will be 50%
                    // 0.0 being 0%
                    // 1.0 being 100%
                    control.setValue((float) 0.5);
                    int value = (int) (control.getValue()*100);
                    pb.setValue(value);
                    j.add(new JLabel(lineinfo.toString()));
                    j.add(pb);
                    j.pack();
                }
            } catch (LineUnavailableException e) {
                e.printStackTrace();
            }
        }
    }
}
public static void main(String[] args) {
    new SoundMeter();
}
}

 */