import java.util.ArrayList;

/**A class to handle basic physics 
 * and collision detection
 * 
 * @author Mitch
 *
 */

public class Physics_Engine 
{
	
	public static final double ACCELERATION_OF_GRAVITY = -0.25;
	
	public static void applyGravity(GameObject someObject)
	{
		if (someObject.isOnGround)
		{
			//Do Nothing
		}
		else
		{
			someObject.myYAcceleration = ACCELERATION_OF_GRAVITY;
		}
	}
	
	public static boolean isOnGround(GameObject someObject)
	{
		if (someObject.getY()-someObject.getHeight()<=15)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/*
	static boolean isOnPlatform(GameObject someEntity,LevelObject someObject)
	{
		if ((someEntity.getX() + someEntity.getWidth()>someObject.getX()-someObject.getWidth())
				&&(someEntity.getX()-someEntity.getWidth()<someEntity.getX() + someEntity.getWidth()))
		{
			if ((someEntity.getY()-someEntity.getHeight()<someObject.getY()+someObject.getHeight())
					&&(someEntity.getY()-someEntity.getHeight()>someObject.getY()+someObject.getHeight()-10))
			{
				//We are on a platform
				someEntity.isJumping = false;
				someEntity.isOnGround = true;
				return true;
			}
		}
		
		return false;
	}
	*/
	
	static boolean isOnPlatform(GameObject someEntity,ArrayList<LevelObject> levelObjects)
	{
		for (int i =0;i<levelObjects.size();i++)
		{
			LevelObject someObject = levelObjects.get(i);
			if ((someEntity.getX() + someEntity.getWidth()>someObject.getX()-someObject.getWidth())
					&&(someEntity.getX()-someEntity.getWidth()<someObject.getX() + someObject.getWidth()))
			{
				if ((someEntity.getY()-someEntity.getHeight()<someObject.getY()+someObject.getHeight())
						&&(someEntity.getY()-someEntity.getHeight()>someObject.getY()+someObject.getHeight()-15))
				{
					//We are on a platform
					if (someEntity.getYVelocity()<0)//we are falling
					{
						someEntity.isJumping = false;
						someEntity.isOnGround = true;
						return true;
					}
				}
			}
		}
		return false;
	}
	
	static boolean isRightCollision(GameObject someObject,ArrayList<LevelObject> levelObjects)
	{
		for (int i =0;i<levelObjects.size();i++)
		{
			LevelObject theLevelObject = levelObjects.get(i);
			if ((someObject.getX() + someObject.getWidth() + someObject.getXVelocity()>theLevelObject.getX()-theLevelObject.getWidth())
					&&(theLevelObject.getX()-theLevelObject.getWidth()>someObject.getX()-someObject.getWidth()))
				if ((someObject.getY()-someObject.getHeight()<theLevelObject.getY() +theLevelObject.getHeight()-15)
						&&(someObject.getY()+someObject.getHeight()>theLevelObject.getY()-theLevelObject.getHeight()))
				{
					//Right Collision
					if (theLevelObject.isActive)
					{
						return true;
					}
				}
		}
		return false;
	}
	
	static boolean isLeftCollision(GameObject someObject,ArrayList<LevelObject> levelObjects)
	{
		for (int i =0;i<levelObjects.size();i++)
		{
			LevelObject theLevelObject = levelObjects.get(i);
			if ((someObject.getX() - someObject.getWidth() - someObject.getXVelocity()<theLevelObject.getX()+theLevelObject.getWidth())
					&&(theLevelObject.getX()+theLevelObject.getWidth()<someObject.getX()+someObject.getWidth()))
				if ((someObject.getY()-someObject.getHeight()<theLevelObject.getY() +theLevelObject.getHeight()-15)
						&&(someObject.getY()+someObject.getHeight()>theLevelObject.getY()-theLevelObject.getHeight()))
				{
					if (theLevelObject.isActive)
					{
						//Left Collision
						return true;
					}
				}
		}
		return false;
	}
	
}
