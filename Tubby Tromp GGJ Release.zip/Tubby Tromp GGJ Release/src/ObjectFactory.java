import java.util.ArrayList;
import java.util.Random;

public class ObjectFactory 
{
	public static void createObject(AssetManager assetManager, String objectType,String gameLevel,double xPosition)
	{
		double randomYPosition = Math.random()*(Game.WINDOW_HEIGHT);
		int randomHeight = (int)(Math.random()*(Game.WINDOW_HEIGHT/11)+30);
		int randomWidth = (int)(Math.random()*(100.0))+50;
		if (gameLevel == "1")
		{
			if (objectType.equals("Platform"))
			{
				if (Game.thePlatformObjects.size()==0)
				{
					LevelObject newObject = new LevelObject(xPosition+60+Game.WINDOW_WIDTH,randomYPosition,175,30,"Images/Pizza.png");
					Game.thePlatformObjects.add(newObject);
				}
				else
				{
					double randX = findRandomX(Game.thePlatformObjects.get(0));
					if (randX<xPosition + Game.WINDOW_WIDTH)
					{
						randX = randX + 1400;
					}
					LevelObject newObject = new LevelObject(randX,randomYPosition,175,30,"Images/Pizza.png");
					Game.thePlatformObjects.add(newObject);
				}	
			}
			else if (objectType.equals("Food"))
			{
				if (Game.theFoodObjects.size()==0)
				{
					//Game.theFoodObjects.add(generateNewFood(assetManager, xPosition + 60 + Game.WINDOW_WIDTH, randomYPosition));
					Food newObject = new Food(xPosition + 60+Game.WINDOW_WIDTH,randomYPosition,70,70,"Images/cookieWalkR1.png");
					Game.theFoodObjects.add(newObject);
				}
				else
				{
					double foodX = generateFoodX();
					//Game.theFoodObjects.add(generateNewFood(assetManager, foodX, randomYPosition));
					Food newObject = new Food(foodX,randomYPosition,70,70,"Images/Cherry_EnemyR1.png");
					Game.theFoodObjects.add(newObject);
				}
				
			}
			else if (objectType.equals("FoodAndPlatform"))
			{
				if (Game.thePlatformObjects.size()==0)
				{
					Game.theFoodObjects.add(generateNewFood(assetManager, xPosition, randomYPosition));
					LevelObject newObject = new LevelObject(xPosition + 110+Game.WINDOW_WIDTH,randomYPosition,randomWidth,30,"Images/Pizza.png");
					Game.thePlatformObjects.add(newObject);
				}
				else
				{
					double randX = findRandomX(Game.thePlatformObjects.get(0));
					if (randX<xPosition + Game.WINDOW_WIDTH)
					{
						randX = randX + 1400;
					}
					LevelObject newObject = new LevelObject(randX,randomYPosition,175,30,"Images/Pizza.png");
					Game.thePlatformObjects.add(newObject);
					Food newFoodObject = new Food(randX + 30-175,randomYPosition+400,70,70,"Cherry_Enemy.png");
					Game.theFoodObjects.add(newFoodObject);
					//Game.theFoodObjects.add(generateNewFood(assetManager, randX + 30-175,randomYPosition+400));
				}
			}
			else if (objectType.equals("Block"))
			{
				/*
				if (Game.theBlockObjects.size()>0)
				{
					double randX = findRandomX(Game.theBlockObjects.get(0));
					if (randX<xPosition + Game.WINDOW_WIDTH)
					{
						randX = randX + 1400;
					}
					LevelObject newObject = new LevelObject(randX,(double)randomHeight,randomHeight,randomHeight,"Images/Pizza.png");
					Game.theBlockObjects.add(newObject);
				}
				else
				{
					LevelObject newObject = new LevelObject(xPosition + 60+Game.WINDOW_WIDTH,randomHeight,randomWidth,randomWidth,"Images/Pizza.png");
					Game.theBlockObjects.add(newObject);
				}
				*/
			}
			else
			{
			}
		}
		else
		{
		}
	}
	
	public static double generateFoodX()
	{
		double farthestX = 0.0;
		for (int i =0;i<Game.theFoodObjects.size();i++)
		{
			if (Game.theFoodObjects.get(i).getX()>farthestX)
			{
				farthestX = Game.theFoodObjects.get(i).getX();
			}
		}
		farthestX = farthestX + Game.WINDOW_WIDTH/2;
		return farthestX;
	}
	
	public static Food generateNewFood(AssetManager assetManager, double x, double y)
	{
		Random rand = new Random();
		int foodType = rand.nextInt(100);
		
		Food newFoodObject;
		
		System.out.println(foodType);
		
		if(foodType < 60) //cherry
		{
			System.out.println("Cherry");
			newFoodObject = new Food(x,y,70,70,assetManager.foodAnim[2], assetManager.foodAnim[3]);
		}
		else
		{
			System.out.println("Oreo");
			newFoodObject = new Food(x,y,70,70,assetManager.foodAnim[0], assetManager.foodAnim[1]);
		}
		
		return newFoodObject;
	}
	
	public static double findRandomX(GameObject oldObject)
	{
		double rand = Math.random()*3000;
		rand = rand + 120 + oldObject.getX();
		return rand;
	}
	
	public static boolean percentChance(int someChance)
	{
		int newInt =(int) (Math.random()*100);
		if (newInt<=someChance)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static void removeOldObjects(int playerX)
	{
		for (int i =0;i<Game.thePlatformObjects.size();i++)
		{
			if (Game.thePlatformObjects.get(i).getX()+700<playerX)
			{
				System.out.println("Objects removed");
				Game.thePlatformObjects.remove(i);
			}
		}
		for (int i =0;i<Game.theBlockObjects.size();i++)
		{
			if (Game.theBlockObjects.get(i).getX()+700<playerX)
			{
				System.out.println("Objects removed");
				Game.theBlockObjects.remove(i);
			}
		}
		for (int i =0;i<Game.theFoodObjects.size();i++)
		{
			if (Game.theFoodObjects.get(i).getX()+700<playerX)
			{
				Game.theFoodObjects.remove(i);
			}
		}
	}
	
	public static void generateObjects(AssetManager assetManager, int xPosition)
	{
		int numPlatformObjects = Game.thePlatformObjects.size();
		int numBlockObjects = Game.theBlockObjects.size();
		int numFood = Game.theFoodObjects.size();
		
		//Check to see if we need more platforms
		if (numPlatformObjects < 5)
		{
			if (percentChance(50))
			{
				ObjectFactory.createObject(assetManager, "Platform","1",xPosition);
			}
			else
			{
				ObjectFactory.createObject(assetManager, "FoodAndPlatform","1",xPosition);
			}
		}
		
		if (numFood<5)
		{
			ObjectFactory.createObject(assetManager, "Food","1",xPosition);
		}
		/*
		if (numBlockObjects < 3)
		{
			ObjectFactory.createObject("Block","1",xPosition);
		}
		if (numFood <3)
		{
			ObjectFactory.createObject("Food","1", xPosition);
		}
		*/
		
		
		/*if (numPlatformObjects<3)
		{
			if (numFood<3)
			{
				if ((numPlatformObjects <2)&&(numFood<2))
				{
					if (percentChance(10))
					{
						ObjectFactory.createObject("FoodAndPlatform","1", xPosition);
						System.out.println("LKSDJF");
					}
				}
			}
			if (numPlatformObjects == 0)
			{
				ObjectFactory.createObject("LevelObject","1",xPosition);
			}
			else if (numPlatformObjects == 1)
			{
				if (percentChance(5))
				{
					ObjectFactory.createObject("LevelObject","1",xPosition);
				}
			}
		}
		if (numBlockObjects<3)
		{
			ObjectFactory.createObject("Block","1",xPosition);
		}
		*/
	}
}
