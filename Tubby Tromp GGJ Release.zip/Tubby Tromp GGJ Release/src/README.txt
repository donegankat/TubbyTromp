-------------------
-------------------
TUBBY TROMP
Global Game Jam 2014
-------------------
-------------------

Programming by:
Kat Donegan, Mitchell Mayeda, Matt Pirtle

Art by:
Anne Woolman, Kacy Corlett, Leonard Pollard, Tom Dice

Sound by:
Ryan Nicholl

-------------------
-------------------

Tubby Tromp was written in Java

To run from source code:
Open the project in Eclipse
Add all .java files to the src directory (no sub-directory required)
Place the 'Images' and 'Sounds' folders in the root directory
Execute Game.java