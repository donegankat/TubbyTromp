import java.util.ArrayList;


public class Game
{
	public static final int WINDOW_WIDTH = 1100;
	public static final int WINDOW_HEIGHT = 600;
	
	//Game States used by the game
	public State_Base currentState;
	private State_L1 myL1State;
	private State_Start myStartState;
	private State_Instruction myInstructionState;
	private State_GameOver myGameOverState;
	private Key_Listener keyListener;
	
	public static ArrayList<LevelObject> thePlatformObjects;
	public static ArrayList<LevelObject> theBlockObjects;
	public static ArrayList<Food> theFoodObjects;
	private long startTime;
	
	private static HappyBGMusicPlayer music;
//	private static ScaryBGMusicPlayer scaryMusic;
	
	public Game()
	{
		keyListener = new Key_Listener();
		
		//Initialize the gameState objects
		myL1State = new State_L1(this, keyListener);
		myStartState = new State_Start(this,keyListener);
		myInstructionState = new State_Instruction(this,keyListener);
		myGameOverState = new State_GameOver(this,keyListener);
		currentState = myStartState;
	}
	
	public void init()
	{		
		startTime = System.currentTimeMillis();
		StdDraw.setCanvasSize(WINDOW_WIDTH,WINDOW_HEIGHT);
		StdDraw.setXscale(0,WINDOW_WIDTH);
		StdDraw.setYscale(0,WINDOW_HEIGHT);
	}
	 
	public void run()
	{
		while (true)
		{
			currentState.run(startTime);
		}
	}

	public void setState(String newState)
	{
		if (newState.equals("L1"))
		{
			currentState = myL1State;
		}
		else if (newState.equals("Instruction"))
		{
			currentState = myInstructionState;
		}
		else if (newState.equals("Start"))
		{
			currentState = myStartState;
		}
		else if (newState.equals("GameOver"))
		{
			currentState = myGameOverState;
		}
	}
	
	
	 

	
	public static void main(String[] args)
	{	
	
		Game newGame = new Game();
		
		setMusic(new HappyBGMusicPlayer());
		Thread t = new Thread(getMusic());
		t.start();
		
//		scaryMusic = new ScaryBGMusicPlayer();
//		Thread t2 = new Thread(scaryMusic);
//		t2.start();
		
		newGame.init();
		newGame.run();

		SoundEffect.init();
		

		
		
		//SoundEffect.volume = SoundEffect.Volume.HIGH;
		//SoundEffect.HAPPY.play();
		//SoundEffect.volume = SoundEffect.Volume.MEDIUM;
		//SoundEffect.volume = SoundEffect.Volume.MUTE;
		//SoundEffect.SCARY.play();
	}

	public static void setMusic(HappyBGMusicPlayer music) {
		Game.music = music;
	}

	public static HappyBGMusicPlayer getMusic() {
		return music;
	}

	/*
	public static void setScaryMusic(ScaryBGMusicPlayer music) {
		Game.scaryMusic = music;
	}

	public static ScaryBGMusicPlayer getScaryMusic() {
		return scaryMusic;
	}
	*/
	 
}
