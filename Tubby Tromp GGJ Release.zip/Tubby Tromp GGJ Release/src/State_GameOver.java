

	public class State_GameOver extends State_Base
	{
		private Game myGame;
		private Key_Listener myListener;
		
		public State_GameOver(Game aGame,Key_Listener someListener)
		{
			myGame = aGame;
			myListener = someListener;
		}
		
		public void run(long updateTime)
		{
			StdDraw.picture(Game.WINDOW_WIDTH/2,Game.WINDOW_HEIGHT/2,"Images/Lose_Screen.png");
			StdDraw.show();
		}
	}

