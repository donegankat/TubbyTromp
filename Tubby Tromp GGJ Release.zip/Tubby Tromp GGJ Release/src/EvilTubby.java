
public class EvilTubby extends GameObject
{
	private Animation run;
	private Animation eat;
	private Animation jump;
	
	public EvilTubby()
	{
		super();
	}
	
	public EvilTubby(double someX,double someY,int someWidth,int someHeight,String someImage)
	{
		super(someX,someY,someWidth,someHeight,someImage);
	}
	
	public EvilTubby(double someX,double someY,int someWidth,int someHeight, Animation r, Animation e, Animation j)
	{
		//super(someX, someY, someWidth, someHeight);
		run = r;
		eat = e;
		jump = j;
	}
	
	public void update(long elapsedTime)
	{
		super.update(elapsedTime);
	}
	
	public void moveRight()
	{
		myX = myX + myXVelocity;
	}
	
	public void moveLeft()
	{
		if (Physics_Engine.isLeftCollision(this,Game.theBlockObjects))
		{
			//Do nothing if collision
		}
		else
		{
			for (int i =0;i<Game.theFoodObjects.size();i++)
			{
				Game.theFoodObjects.get(i).setX(Game.theFoodObjects.get(i).getX() + myXVelocity);
			}
			for (int i =0;i<Game.thePlatformObjects.size();i++)
			{
				Game.thePlatformObjects.get(i).setX(Game.thePlatformObjects.get(i).getX() + myXVelocity);
			}
			for (int i =0;i<Game.theBlockObjects.size();i++)
			{
				Game.theBlockObjects.get(i).setX(Game.theBlockObjects.get(i).getX() + myXVelocity);
			}
		}
	}
	
	public void draw()
	{
		super.draw();
	}
}
