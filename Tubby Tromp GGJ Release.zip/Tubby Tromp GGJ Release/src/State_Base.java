
public abstract class State_Base 
{
	public abstract void run(long start);
}
