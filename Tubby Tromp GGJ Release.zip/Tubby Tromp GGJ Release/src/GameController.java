import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

public class GameController implements KeyListener
{
	public GameObject player;
	public ArrayList<Food> foodArray;
	public int score = 0;
	
	public GameController()
	{
		player = new Player();
		foodArray = new ArrayList<Food>();
		
		Random rand = new Random();
		
		//Create instances of food of random type and random distance (between 50 and 100) in front of player
		for(int i = 0; i < 20; i++)
		{
			int foodType = rand.nextInt(3); //inclusive 0 to 3
			int tempX = rand.nextInt(50) + 50;
		
			Food food = new Food();
			foodArray.add(i, food);
		}
		
	}
	
	public void update()
	{
		
	}
	
	public void collisionCheck()
	{
		for(int i = 0; i < foodArray.size(); i++)
		{
			Food tempFood = foodArray.get(i);
			if(player.getX() + player.getWidth() >= tempFood.getX() && player.getX() <= tempFood.getX() + tempFood.getWidth())
			{
				if(player.getY() + player.getHeight() >= tempFood.getY() && player.getY() <= tempFood.getY() + tempFood.getHeight())
				{
					//collision
					foodArray.remove(i);
					score ++;
					//play collision sound
					
				}
			}
		
		}
	}

	@Override
	public void keyPressed(KeyEvent e)
	{
		if(e.equals(KeyEvent.VK_RIGHT))
		{
			player.setX(player.getX() + 10);
		}
		
		if(e.equals(KeyEvent.VK_LEFT))
		{
			player.setX(player.getX()-10);
		}
		
		if(e.equals(KeyEvent.VK_SPACE) && player.isJumping == false)
		{
			//jump
			player.isJumping = true;
			
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e)
	{
		if(e.equals(KeyEvent.VK_RIGHT))
		{
			player.setX(player.getX() + 10);
		}
		
		if(e.equals(KeyEvent.VK_LEFT))
		{
			player.setX(player.getX() - 10);
		}
		
		if(e.equals(KeyEvent.VK_SPACE))
		{
			//cancel jump
			player.isJumping = false;
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
