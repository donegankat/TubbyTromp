
public class Player extends GameObject
{
	public Player()
	{
		super();
	}
	
	public Player(double someX,double someY,int someWidth,int someHeight,String someImage)
	{
		super(someX,someY,someWidth,someHeight,someImage);
	}
	
	public Player(double someX,double someY,int someWidth,int someHeight, Animation run, Animation eat, Animation jump)
	{
		super(someX, someY, someWidth, someHeight, run, eat, jump);
	}
	
	public void update(long elapsedTime)
	{
		super.update(elapsedTime);
	}
	
	public void moveRight()
	{
		
		/*
		//Check Food collisions
		if (Physics_Engine.isFoodCollision(this,Game.theFoodObjects))
		{
			if(state == 0 || state == 2) //if he collides while jumping or running
			{
				state = 1; //set him to eat
				foodTime = System.currentTimeMillis();
			}
		}
*/
		
		if (Physics_Engine.isRightCollision(this,Game.theBlockObjects))
		{
			//Do nothing if collision
		}
		else
		{
			for (int i =0;i<Game.theFoodObjects.size();i++)
			{
				Game.theFoodObjects.get(i).setX(Game.theFoodObjects.get(i).getX() - myXVelocity);
			}
			for (int i =0;i<Game.thePlatformObjects.size();i++)
			{
				Game.thePlatformObjects.get(i).setX(Game.thePlatformObjects.get(i).getX() - myXVelocity);
			}
			for (int i =0;i<Game.theBlockObjects.size();i++)
			{
				Game.theBlockObjects.get(i).setX(Game.theBlockObjects.get(i).getX() - myXVelocity);
			}
		}
		State_L1.backgroundX = State_L1.backgroundX - 1;
		State_L1.backgroundX2 = State_L1.backgroundX2 - 1;
		State_L1.floorX = State_L1.floorX - 6;
		State_L1.floorX2 = State_L1.floorX2 - 6;
	}
	
	public void moveLeft()
	{
		if (Physics_Engine.isLeftCollision(this,Game.theBlockObjects))
		{
			//Do nothing if collision
		}
		else
		{
			for (int i =0;i<Game.theFoodObjects.size();i++)
			{
				Game.theFoodObjects.get(i).setX(Game.theFoodObjects.get(i).getX() + myXVelocity);
			}
			for (int i =0;i<Game.thePlatformObjects.size();i++)
			{
				Game.thePlatformObjects.get(i).setX(Game.thePlatformObjects.get(i).getX() + myXVelocity);
			}
			for (int i =0;i<Game.theBlockObjects.size();i++)
			{
				Game.theBlockObjects.get(i).setX(Game.theBlockObjects.get(i).getX() + myXVelocity);
			}
		}
	}
	
	public void draw()
	{
		super.draw();
		
	}
}
