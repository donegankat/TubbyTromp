import java.awt.Image;

/**Extends GameObject.  LevelObjects
 * are inanimate and the player
 * cannot move through them.
 * 
 * @author Mitch
 *
 */


public class LevelObject extends GameObject
{
	public boolean isActive;
	
	public LevelObject()
	{
		myX = myY = 0;
		myWidth = myHeight = 0;
		myXVelocity = myYVelocity = 0;
		myYAcceleration = 0;
		isActive = true;
	}
	
	public LevelObject(double someX,double someY,int someWidth,int someHeight,String someImage)
	{
		super(someX,someY,someWidth,someHeight,someImage);
		myXVelocity = myYVelocity = 0;
		myYAcceleration = 0;
		isActive = true;
		myImage = someImage;
	}
	
	public LevelObject(double someX,double someY,int someWidth,int someHeight,Image someImage)
	{
		super(someX,someY,someWidth,someHeight,someImage);
		myXVelocity = myYVelocity = 0;
		myYAcceleration = 0;
		isActive = true;
		currentImage = someImage;
	}
	
	public void update(long elapsedTime)
	{
		//Do Nothing
	}
	
	public void draw()
	{
		StdDraw.picture(myX, myY,myImage,myWidth*2,myHeight*2);
	}
	
	/***************Getters and Setters for LevelObjects**************/
	//These override the GameObject setters to ensure that our level
	//objects never have a velocity.
	public void setXVelocity(double someVelocity)
	{
		myXVelocity = 0;
	}
	public void setYVelocity(double someVelocity)
	{
		myYVelocity = 0;
	}
	public void setYAcceleration(double someAcceleration)
	{
		myYAcceleration = 0;
	}
}
