
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/** A class responsible for sensing key presses
 * and releases.  Static booleans keep track
 * of whether or not a desired key is currently
 * pressed
 * 
 * @author Mitch
 *
 */
public class Key_Listener extends KeyAdapter
{
	private static boolean spacePressed = false;
	private static boolean leftPressed = false;
	private static boolean rightPressed = false;
	
	public Key_Listener()
	{
	}
	
	public boolean isRightPressed()
	{
		return rightPressed;
	}
	
	public boolean isLeftPressed()
	{
		return leftPressed;
	}
	
	public boolean isSpacePressed()
	{
		return spacePressed;
	}
	
	public void keyReleased(KeyEvent event)
	{
		char ch = event.getKeyChar();
		if(event.getKeyCode() == KeyEvent.VK_LEFT)
		{
			leftPressed = false;
		}
		if(event.getKeyCode() == KeyEvent.VK_RIGHT)
		{
			rightPressed = false;
		}
		if (ch == ' ')
		{
			spacePressed = false;
		}
	}
	
	public void keyPressed(KeyEvent event)
	{
		char ch = event.getKeyChar();
		if(event.getKeyCode() == KeyEvent.VK_LEFT)
		{
			leftPressed = true;
		}
		if(event.getKeyCode() == KeyEvent.VK_RIGHT)
		{
			rightPressed = true;
		}
		if (ch == ' ')
		{
			spacePressed = true;
		}

	}
	
	public static void main(String[] args)
	{
	}
}