import java.awt.Image;
import java.util.ArrayList;
/**
 * This code was created by David Brackeen
 * http://www.brackeen.com/javagamebook/
**/
public class Animation {
	private ArrayList<Frame> frames;
	private int currentFrameIndex;
	private long animationTime;
	private long totalDuration;
	
	public Animation()
	{
        this(new ArrayList<Frame>(), 0);
    }
    private Animation(ArrayList<Frame> frames, long totalDuration)
    {
        this.frames = frames;
        this.totalDuration = totalDuration;
        startAnimation();
    }
    
    /**Creates duplicate of the animation.
     * The list of frames are shared between the two Animations,
     * but each Animation can be animated independently.**/
    public Object clone()
    {
    	return new Animation(frames, totalDuration);
    }
    
    /**Add a new frame to the array that will display for the specified duration**/
    public synchronized void addFrame(Image image, long duration)
    {
    	totalDuration += duration;
    	frames.add(new Frame(image, totalDuration));
    }
    
    /**Start animation over from beginning**/
    public synchronized void startAnimation()
    {
    	animationTime = 0;
    	currentFrameIndex = 0;
    }
    
    public synchronized void update(long elapsedTime)
    {
    	if(frames.size() > 1)
    	{
            animationTime += 1;//elapsedTime;
            if(animationTime >= totalDuration)
            {
                animationTime = 0;//animationTime % totalDuration;
                currentFrameIndex = 0;
            }
            while(animationTime > getFrame(currentFrameIndex).frameDuration)
            {
                currentFrameIndex++;
            }
        }
    }
    
    public synchronized Image getImage()
    {
        if (frames.size() == 0)
        {
            return null;
        }
        else
        {
            return getFrame(currentFrameIndex).frameImage;
        }
    }
	
    public Image getFrameImage(int index)
    {
    	return frames.get(index).frameImage;
    }
    
    private Frame getFrame(int index)
    {
    	return frames.get(index);
    }
    
    private class Frame
    {
    	Image frameImage;
    	long frameDuration;
    	
    	private Frame(Image image, long duration)
    	{
    		frameImage = image;
    		frameDuration = duration;
    	}
    }
}