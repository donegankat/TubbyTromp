
public class State_Instruction extends State_Base
{
	private Game myGame;
	private Key_Listener myListener;
	
	public State_Instruction(Game aGame,Key_Listener someListener)
	{
		myGame = aGame;
		myListener = someListener;
	}
	
	public void run(long startTime)
	{
		draw();
		if (StdDraw.mousePressed())
		{
			myGame.setState("L1");
			StdDraw.setMousePressed(false);
		}
	}
	
	public void draw()
	{
		StdDraw.picture(Game.WINDOW_WIDTH/2,Game.WINDOW_HEIGHT/2,"Images/Intro_Screen.png");
	}
}
