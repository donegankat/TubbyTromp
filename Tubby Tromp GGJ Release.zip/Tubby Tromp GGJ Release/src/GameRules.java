
public class GameRules
{
	
	public float calories;
	public int score;
	private long time;
	
	public GameRules()
	{
		calories = 500;
		score = 0;
		time = 0;
	}
	
	public float getCalories()
	{
		return calories;
	}
	
	public int getScore()
	{
		return score;
	}
	
	public long getTime()
	{
		return time;
	}
	
	public void setCalories(float newCals)
	{
		calories = newCals;
	}
	
	public void setScore(int newScore)
	{
		score = newScore;
	}
	
	public void setTime(long newTime)
	{
		time = newTime;
	}
	
	public void update(long timeElapsed)
	{
		if(calories > 0)
		{
			calories -= 1.5;
		}
	}
	
	public boolean playerIntersectsFood(Player aPlayer)
	{
		for (int i =0;i<Game.theFoodObjects.size();i++)
		{
			if (aPlayer.doesCollide(Game.theFoodObjects.get(i)))
			{
				Game.theFoodObjects.remove(i);
				return true;
			}
		}
		return false;
	}
	
	public boolean playerStarved()
	{
		if (getCalories()<=0)
		{
			return true;
		}
		return false;
	}
	
}
